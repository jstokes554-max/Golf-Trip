"use client";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { useTripData, DEFAULT_PAR, DEFAULT_SI } from "../../lib/hooks";

// =====================================================
// CONSTANTS (unchanged from original)
// =====================================================
const TC = ["#3a8f6a", "#2563a8"];
const TL = ["#5ecea0", "#4da8e8"];
const TB = ["rgba(58,143,106,0.1)", "rgba(37,99,168,0.1)"];

const ROUNDS_INFO = {
  1: { name: "Team Scramble", desc: "2-man pods scramble. Lowest net wins each match.", format: "scramble" },
  2: { name: "Four-Ball Best Ball", desc: "Best net score per hole. Most holes won takes the match.", format: "bestball" },
  3: { name: "Singles Match Play", desc: "1v1 head to head, strokes by handicap differential.", format: "singles" },
  4: { name: "Vegas", desc: "2v2 pairs combine net scores low-high. Birdies flip the opponent's number.", format: "vegas" },
};

// =====================================================
// STROKE ALLOCATION (USGA) — unchanged from original
// =====================================================
function allocateStrokes(strokeCount, courseSI) {
  const arr = new Array(18).fill(0);
  if (strokeCount <= 0 || !courseSI) return arr;
  for (let i = 0; i < strokeCount; i++) {
    const targetSI = (i % 18) + 1;
    const idx = courseSI.indexOf(targetSI);
    if (idx >= 0) arr[idx]++;
  }
  return arr;
}

function getIndividualStrokes(playerHcps, courseSI) {
  const hcps = Object.values(playerHcps);
  if (!hcps.length) return {};
  const lowest = Math.min(...hcps);
  const result = {};
  Object.entries(playerHcps).forEach(([pid, hcp]) => {
    result[pid] = allocateStrokes(hcp - lowest, courseSI);
  });
  return result;
}

function teamHcp(hcps) {
  if (!hcps.length) return 0;
  const sorted = [...hcps].sort((a, b) => a - b);
  if (sorted.length === 1) return Math.round(sorted[0] * 0.35);
  return Math.round(sorted[0] * 0.35 + sorted[1] * 0.15);
}

function getScrambleStrokes(aHcps, bHcps, courseSI) {
  const a = teamHcp(aHcps);
  const b = teamHcp(bHcps);
  const lowest = Math.min(a, b);
  return {
    sideA: allocateStrokes(a - lowest, courseSI),
    sideB: allocateStrokes(b - lowest, courseSI),
    aHcp: a,
    bHcp: b,
  };
}

const sumArr = (a) => (a || []).reduce((s, x) => s + (x || 0), 0);

// =====================================================
// MATCH STATUS COMPUTATION — unchanged from original
// =====================================================
function computeMatchStatus(format, course, match, players) {
  const out = {
    holesA: 0, holesB: 0, vegasA: 0, vegasB: 0,
    holesPlayed: 0, sideResult: null,
    strokesByPid: {}, scrambleStrokes: null,
    holeWinners: new Array(18).fill(null),
  };
  if (!course || !match) return out;
  const getP = (pid) => players.find((p) => p.id === pid);

  if (format === "scramble") {
    const aHcps = match.sideA.map((pid) => getP(pid)?.handicap ?? 0);
    const bHcps = match.sideB.map((pid) => getP(pid)?.handicap ?? 0);
    out.scrambleStrokes = getScrambleStrokes(aHcps, bHcps, course.si);
    for (let h = 0; h < 18; h++) {
      const gA = match.scores?.sideA?.[h];
      const gB = match.scores?.sideB?.[h];
      const fA = gA != null && gA !== "";
      const fB = gB != null && gB !== "";
      if (!fA || !fB) continue;
      out.holesPlayed++;
      const netA = parseFloat(gA) - out.scrambleStrokes.sideA[h];
      const netB = parseFloat(gB) - out.scrambleStrokes.sideB[h];
      if (netA < netB) { out.holesA++; out.holeWinners[h] = "A"; }
      else if (netB < netA) { out.holesB++; out.holeWinners[h] = "B"; }
      else { out.holeWinners[h] = "H"; }
    }
  } else {
    const allPids = [...match.sideA, ...match.sideB];
    const hcps = {};
    allPids.forEach((pid) => { hcps[pid] = getP(pid)?.handicap ?? 0; });
    out.strokesByPid = getIndividualStrokes(hcps, course.si);

    for (let h = 0; h < 18; h++) {
      const netByPid = {};
      let allFilled = true;
      allPids.forEach((pid) => {
        const g = match.scores?.[pid]?.[h];
        if (g == null || g === "") { allFilled = false; return; }
        netByPid[pid] = parseFloat(g) - (out.strokesByPid[pid]?.[h] ?? 0);
      });
      if (!allFilled) continue;
      out.holesPlayed++;

      if (format === "vegas") {
        const aNets = match.sideA.map((pid) => netByPid[pid]).sort((x, y) => x - y);
        const bNets = match.sideB.map((pid) => netByPid[pid]).sort((x, y) => x - y);
        if (aNets.length < 2 || bNets.length < 2) continue;
        const par = course.par[h];
        let aNum = aNets[0] * 10 + aNets[1];
        let bNum = bNets[0] * 10 + bNets[1];
        if (aNets[0] < par) bNum = bNets[1] * 10 + bNets[0];
        if (bNets[0] < par) aNum = aNets[1] * 10 + aNets[0];
        if (aNum < bNum) { out.vegasA += (bNum - aNum); out.holeWinners[h] = "A"; }
        else if (bNum < aNum) { out.vegasB += (aNum - bNum); out.holeWinners[h] = "B"; }
        else out.holeWinners[h] = "H";
      } else {
        const aBest = Math.min(...match.sideA.map((pid) => netByPid[pid]));
        const bBest = Math.min(...match.sideB.map((pid) => netByPid[pid]));
        if (aBest < bBest) { out.holesA++; out.holeWinners[h] = "A"; }
        else if (bBest < aBest) { out.holesB++; out.holeWinners[h] = "B"; }
        else out.holeWinners[h] = "H";
      }
    }
  }

  if (out.holesPlayed > 0) {
    if (format === "vegas") {
      if (out.vegasA > out.vegasB) out.sideResult = "sideA";
      else if (out.vegasB > out.vegasA) out.sideResult = "sideB";
      else out.sideResult = "tie";
    } else {
      if (out.holesA > out.holesB) out.sideResult = "sideA";
      else if (out.holesB > out.holesA) out.sideResult = "sideB";
      else out.sideResult = "tie";
    }
  }
  return out;
}

// =====================================================
// MAIN COMPONENT
// =====================================================
export default function TripPage({ params }) {
  const tripCode = params.tripCode;
  const {
    players,
    teamNames,
    courses,
    matches,
    loading,
    error,
    addPlayer,
    removePlayer,
    assignPlayer,
    updateTeamName,
    setCourse,
    addMatch: mutAddMatch,
    removeMatch,
    setManualResult,
    setHoleScore,
  } = useTripData(tripCode);

  // Local UI state
  const [view, setView] = useState("roster");
  const [editTi, setEditTi] = useState(null);
  const [editTv, setEditTv] = useState("");
  const [pf, setPf] = useState({ name: "", hcp: "" });
  const [modal, setModal] = useState(null);
  const [scoring, setScoring] = useState(null);
  const [editCourse, setEditCourse] = useState(null);

  const tp = (ti) => players.filter((p) => p.team === ti);
  const pById = (id) => players.find((p) => p.id === id);
  const pName = (id) => {
    if (!id) return "";
    const p = pById(id);
    return p ? p.name : "(removed)";
  };
  const pH = (id) => pById(id)?.handicap ?? 0;
  const pTeam = (id) => pById(id)?.team ?? 0;

  const handleAddPlayer = () => {
    const h = parseInt(pf.hcp);
    if (!pf.name.trim() || isNaN(h) || h < 0) return;
    addPlayer(pf.name.trim(), h);
    setPf({ name: "", hcp: "" });
  };

  const handleAddMatch = () => {
    if (!modal || (modal.sideA.length === 0 && modal.sideB.length === 0)) return;
    mutAddMatch(modal.rid, modal.sideA, modal.sideB);
    setModal(null);
  };

  const toggleSide = (sk, pid) => setModal((prev) => {
    const arr = prev[sk];
    return { ...prev, [sk]: arr.includes(pid) ? arr.filter((x) => x !== pid) : [...arr, pid] };
  });

  const matchHasScores = (m) => {
    if (!m.scores) return false;
    return Object.values(m.scores).some((arr) => Array.isArray(arr) && arr.some((v) => v != null && v !== ""));
  };

  const initCourse = (rid) => {
    if (!courses[rid]) {
      setCourse(rid, { name: "", par: DEFAULT_PAR, si: DEFAULT_SI });
    }
    setEditCourse(rid);
  };

  const setCourseField = (rid, field, val) => setCourse(rid, { [field]: val });

  const setCourseHole = (rid, field, holeIdx, val) => {
    const c = courses[rid] || { par: [...DEFAULT_PAR], si: [...DEFAULT_SI] };
    const arr = [...c[field]];
    const num = parseInt(val);
    arr[holeIdx] = isNaN(num) ? 0 : num;
    setCourse(rid, { [field]: arr });
  };

  const applyDefault = (rid) => {
    setCourse(rid, { par: DEFAULT_PAR, si: DEFAULT_SI });
  };

  const getMatchSideResult = (rid, m) => {
    if (!m) return null;
    if (matchHasScores(m)) {
      const status = computeMatchStatus(ROUNDS_INFO[rid].format, courses[rid], m, players);
      return status.sideResult;
    }
    if (m.manualResult === "tie") return "tie";
    if (m.manualResult === "t1" || m.manualResult === "t2") {
      const aTeam = pTeam(m.sideA[0]);
      if (m.manualResult === "t1") return aTeam === 0 ? "sideA" : "sideB";
      return aTeam === 0 ? "sideB" : "sideA";
    }
    return null;
  };

  const getRoundPts = (rid) => {
    const pts = [0, 0];
    (matches[rid] || []).forEach((m) => {
      const r = getMatchSideResult(rid, m);
      if (r === "tie") { pts[0] += 0.5; pts[1] += 0.5; }
      else if (r === "sideA") { pts[pTeam(m.sideA[0])]++; }
      else if (r === "sideB") { pts[pTeam(m.sideB[0])]++; }
    });
    return pts;
  };

  const totalPts = [0, 0];
  [1, 2, 3, 4].forEach((r) => {
    const p = getRoundPts(r);
    totalPts[0] += p[0];
    totalPts[1] += p[1];
  });

  const S = {
    app: { minHeight: "100vh", background: "#0b1c11", fontFamily: "'DM Sans', sans-serif", color: "#ddd8c0", paddingBottom: 88 },
    hdr: { padding: "20px 18px 0", background: "linear-gradient(180deg,#081410 0%,transparent 100%)", borderBottom: "1px solid rgba(201,168,76,0.12)" },
    title: { fontFamily: "'Playfair Display', serif", fontSize: 26, fontWeight: 900, color: "#c9a84c", margin: "0 0 2px", letterSpacing: -0.5 },
    sub: { fontSize: 10, color: "#4a6a54", letterSpacing: 2.5, textTransform: "uppercase", marginBottom: 14 },
    scoreRow: { display: "flex", gap: 10, marginBottom: 16 },
    sBox: (ti, lead) => ({ flex: 1, padding: "12px 14px", borderRadius: 10, background: TB[ti], border: `1px solid ${lead ? TC[ti] : TC[ti] + "30"}`, textAlign: "center", position: "relative" }),
    sNum: (ti) => ({ fontSize: 34, fontWeight: 700, color: TL[ti], fontFamily: "'Playfair Display', serif", lineHeight: 1 }),
    sLbl: { fontSize: 10, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1.5, marginTop: 3 },
    tabBar: { display: "flex", background: "rgba(0,0,0,0.3)", borderBottom: "1px solid rgba(255,255,255,0.05)" },
    tab: (active) => ({ flex: 1, padding: "11px 4px", background: "none", border: "none", borderBottom: active ? "2px solid #c9a84c" : "2px solid transparent", color: active ? "#c9a84c" : "#4a6a54", fontSize: 11, fontWeight: active ? 600 : 400, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", letterSpacing: 0.5 }),
    content: { padding: "18px 16px", maxWidth: 540, margin: "0 auto" },
    sh: { fontFamily: "'Playfair Display', serif", fontSize: 16, fontWeight: 700, color: "#c9a84c", marginBottom: 14, marginTop: 6 },
    card: { background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 14, marginBottom: 10 },
    inp: { width: "100%", boxSizing: "border-box", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 8, padding: "9px 12px", color: "#ddd8c0", fontSize: 13, fontFamily: "'DM Sans', sans-serif", outline: "none" },
    btn: (v) => ({ padding: "9px 16px", borderRadius: 8, border: v === "ghost" ? "1px solid rgba(255,255,255,0.12)" : "none", cursor: "pointer", fontSize: 12, fontWeight: 600, fontFamily: "'DM Sans', sans-serif", background: v === "gold" ? "#c9a84c" : v === "ghost" ? "transparent" : "rgba(255,255,255,0.07)", color: v === "gold" ? "#0b1c11" : "#ddd8c0" }),
    chip: (ti, sel) => ({ display: "inline-flex", alignItems: "center", gap: 5, padding: "5px 10px", borderRadius: 20, margin: 3, background: sel ? TC[ti] + "cc" : "rgba(255,255,255,0.05)", border: `1px solid ${sel ? TC[ti] : "rgba(255,255,255,0.08)"}`, color: sel ? "#fff" : "#9a9480", fontSize: 12, cursor: "pointer" }),
    rBtn: (active, col) => ({ flex: 1, padding: "8px 4px", borderRadius: 8, border: `1px solid ${active ? col : "rgba(255,255,255,0.07)"}`, background: active ? `${col}22` : "transparent", color: active ? col : "#3a4a3a", fontSize: 11, fontWeight: active ? 700 : 400, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }),
    overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.82)", zIndex: 50, display: "flex", alignItems: "flex-end" },
    modalBox: { width: "100%", background: "#112419", borderRadius: "16px 16px 0 0", padding: 20, maxHeight: "78vh", overflowY: "auto", border: "1px solid rgba(201,168,76,0.12)", borderBottom: "none" },
    scoreInp: { width: 52, textAlign: "center", padding: "8px 4px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, color: "#ddd8c0", fontSize: 14, fontFamily: "'DM Sans', sans-serif", outline: "none", fontWeight: 600 },
  };

  // ===================================================
  // LOADING + ERROR STATES
  // ===================================================
  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: "#0b1c11", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans', sans-serif" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#c9a84c", marginBottom: 8 }}>Loading trip...</div>
          <div style={{ fontSize: 11, color: "#4a6a54", letterSpacing: 2, textTransform: "uppercase" }}>{tripCode}</div>
        </div>
      </div>
    );
  }

  if (error === "not_found") {
    return (
      <div style={{ minHeight: "100vh", background: "#0b1c11", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans', sans-serif", padding: 20 }}>
        <div style={{ textAlign: "center", maxWidth: 320 }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: "#c9a84c", marginBottom: 10 }}>Trip not found</div>
          <div style={{ fontSize: 13, color: "#9aa490", marginBottom: 24 }}>No trip exists with the code <strong style={{ color: "#ddd8c0" }}>{tripCode}</strong>.</div>
          <Link href="/" style={{ display: "inline-block", padding: "10px 20px", background: "#c9a84c", color: "#0b1c11", borderRadius: 8, textDecoration: "none", fontSize: 13, fontWeight: 600 }}>Back to home</Link>
        </div>
      </div>
    );
  }

  // ===================================================
  // RENDER FUNCTIONS (preserved from original)
  // ===================================================

  const renderRoster = () => (
    <div>
      <div style={S.sh}>Add Player</div>
      <div style={S.card}>
        <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
          <input style={{ ...S.inp, flex: 3 }} placeholder="Player name" value={pf.name} onChange={(e) => setPf((f) => ({ ...f, name: e.target.value }))} onKeyDown={(e) => e.key === "Enter" && handleAddPlayer()} />
          <input style={{ ...S.inp, flex: 1 }} placeholder="HCP" type="number" min="0" max="54" value={pf.hcp} onChange={(e) => setPf((f) => ({ ...f, hcp: e.target.value }))} onKeyDown={(e) => e.key === "Enter" && handleAddPlayer()} />
        </div>
        <button style={{ ...S.btn("gold"), width: "100%" }} onClick={handleAddPlayer}>Add to Roster</button>
      </div>

      {players.length > 0 && (
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, marginTop: 14, alignItems: "baseline" }}>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#c9a84c", fontFamily: "'Playfair Display', serif" }}>The Field ({players.length})</span>
          <span style={{ fontSize: 11, color: "#4a6a54" }}>Avg HCP: {(players.reduce((s, p) => s + p.handicap, 0) / players.length).toFixed(1)}</span>
        </div>
      )}

      {[...players].sort((a, b) => a.handicap - b.handicap).map((p) => (
        <div key={p.id} style={{ ...S.card, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", marginBottom: 6 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: p.team === null ? "#3a4a3a" : TC[p.team], flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 500 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: "#4a6a54", marginTop: 1 }}>
                HCP {p.handicap}
                {p.team !== null && <span style={{ color: TL[p.team] }}> · {teamNames[p.team]}</span>}
                {p.team === null && <span> · Undrafted</span>}
              </div>
            </div>
          </div>
          <button onClick={() => removePlayer(p.id)} style={{ background: "none", border: "none", color: "#3a4a3a", cursor: "pointer", fontSize: 20, padding: "0 4px" }}>×</button>
        </div>
      ))}

      {players.length === 0 && (
        <div style={{ textAlign: "center", padding: "32px 0", color: "#3a5040" }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>⛳</div>
          <div style={{ fontSize: 13 }}>Add players and their handicaps to load the field</div>
          <div style={{ fontSize: 11, marginTop: 6, color: "#2a3a2a" }}>You'll draft them onto teams next</div>
        </div>
      )}
    </div>
  );

  const renderDraft = () => {
    const unassigned = players.filter((p) => p.team === null).sort((a, b) => a.handicap - b.handicap);
    return (
      <div>
        <div style={S.sh}>Team Names</div>
        <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
          {[0, 1].map((i) => (
            <div key={i} style={{ flex: 1 }}>
              {editTi === i ? (
                <div style={{ display: "flex", gap: 6 }}>
                  <input style={S.inp} value={editTv} autoFocus onChange={(e) => setEditTv(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { updateTeamName(i, editTv); setEditTi(null); } }} />
                  <button style={S.btn("gold")} onClick={() => { updateTeamName(i, editTv); setEditTi(null); }}>OK</button>
                </div>
              ) : (
                <div onClick={() => { setEditTi(i); setEditTv(teamNames[i]); }} style={{ padding: "10px 14px", borderRadius: 10, background: TB[i], border: `1px solid ${TC[i]}40`, cursor: "pointer" }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: TL[i] }}>{teamNames[i]}</div>
                  <div style={{ fontSize: 10, color: "#4a6a54", marginTop: 2 }}>Tap to rename</div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div style={S.sh}>Team Rosters</div>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          {[0, 1].map((ti) => {
            const tPlrs = tp(ti).sort((a, b) => a.handicap - b.handicap);
            const avg = tPlrs.length ? (tPlrs.reduce((s, p) => s + p.handicap, 0) / tPlrs.length).toFixed(1) : "—";
            return (
              <div key={ti} style={{ flex: 1, padding: 12, borderRadius: 10, background: TB[ti], border: `1px solid ${TC[ti]}40`, minHeight: 140 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
                  <span style={{ fontSize: 18, fontWeight: 700, color: TL[ti], fontFamily: "'Playfair Display', serif" }}>{tPlrs.length}</span>
                  <span style={{ fontSize: 10, color: "#4a6a54" }}>HCP {avg}</span>
                </div>
                {tPlrs.length === 0 ? (
                  <div style={{ fontSize: 11, color: "#3a5040", fontStyle: "italic" }}>No picks yet</div>
                ) : (
                  tPlrs.map((p) => (
                    <div key={p.id} onClick={() => assignPlayer(p.id, null)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 8px", marginBottom: 4, background: "rgba(0,0,0,0.22)", borderRadius: 6, cursor: "pointer" }}>
                      <span style={{ fontSize: 12 }}>{p.name}</span>
                      <span style={{ fontSize: 10, color: "#6a7a6a" }}>{p.handicap}</span>
                    </div>
                  ))
                )}
              </div>
            );
          })}
        </div>

        {(tp(0).length > 0 || tp(1).length > 0) && (
          <div style={{ fontSize: 10, color: "#4a6a54", marginBottom: 16, textAlign: "center", letterSpacing: 0.5 }}>Tap a drafted player to return them to the pool</div>
        )}

        <div style={S.sh}>Available ({unassigned.length})</div>
        {players.length === 0 && (<div style={{ textAlign: "center", padding: "24px 0", color: "#3a5040", fontSize: 13 }}>Load players in the Roster tab first</div>)}
        {players.length > 0 && unassigned.length === 0 && (<div style={{ textAlign: "center", padding: "24px 0", color: "#3a5040", fontSize: 13 }}>All players drafted ⛳</div>)}
        {unassigned.map((p) => (
          <div key={p.id} style={{ ...S.card, display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", marginBottom: 6 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: "#4a6a54" }}>HCP {p.handicap}</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {[0, 1].map((ti) => {
                const parts = teamNames[ti].split(" ");
                const shortName = parts[parts.length - 1];
                return (
                  <button key={ti} onClick={() => assignPlayer(p.id, ti)} style={{ padding: "6px 10px", borderRadius: 6, border: `1px solid ${TC[ti]}60`, background: `${TC[ti]}20`, color: TL[ti], fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>→ {shortName}</button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderBoard = () => (
    <div>
      <div style={S.sh}>Overall Standings</div>
      <div style={S.scoreRow}>
        {[0, 1].map((i) => {
          const lead = totalPts[i] > totalPts[1 - i];
          return (
            <div key={i} style={S.sBox(i, lead)}>
              {lead && (<div style={{ position: "absolute", top: 5, right: 8, fontSize: 9, color: TL[i], fontWeight: 700, letterSpacing: 1 }}>LEADING</div>)}
              <div style={S.sNum(i)}>{totalPts[i]}</div>
              <div style={S.sLbl}>{teamNames[i]}</div>
            </div>
          );
        })}
      </div>

      <div style={S.sh}>Round Breakdown</div>
      {[1, 2, 3, 4].map((rid) => {
        const info = ROUNDS_INFO[rid];
        const pts = getRoundPts(rid);
        const played = pts[0] > 0 || pts[1] > 0;
        const t1Win = pts[0] > pts[1];
        const t2Win = pts[1] > pts[0];
        return (
          <div key={rid} style={{ ...S.card, display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }} onClick={() => setView(`r${rid}`)}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600 }}>R{rid} · {info.name}</div>
              {!played && <div style={{ fontSize: 11, color: "#3a4a3a", marginTop: 2 }}>Not started</div>}
              {played && (<div style={{ fontSize: 11, color: "#4a6a54", marginTop: 2 }}>{t1Win ? teamNames[0] : t2Win ? teamNames[1] : "All square"}</div>)}
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <span style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Playfair Display', serif", color: t1Win ? TL[0] : pts[0] === pts[1] && pts[0] > 0 ? "#c9a84c" : "#2a3a2a" }}>{pts[0]}</span>
              <span style={{ color: "#2a3a2a", fontSize: 12 }}>–</span>
              <span style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Playfair Display', serif", color: t2Win ? TL[1] : pts[1] === pts[0] && pts[1] > 0 ? "#c9a84c" : "#2a3a2a" }}>{pts[1]}</span>
            </div>
          </div>
        );
      })}

      {players.length > 0 && (
        <>
          <div style={{ ...S.sh, marginTop: 20 }}>All Players</div>
          {[...players].sort((a, b) => a.handicap - b.handicap).map((p) => (
            <div key={p.id} style={{ ...S.card, display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", marginBottom: 6 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: p.team === null ? "#3a4a3a" : TC[p.team], flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</div>
                <div style={{ fontSize: 11, color: p.team === null ? "#4a6a54" : TL[p.team] }}>{p.team === null ? "Undrafted" : teamNames[p.team]}</div>
              </div>
              <div style={{ fontSize: 12, color: "#4a6a54" }}>HCP {p.handicap}</div>
            </div>
          ))}
        </>
      )}
    </div>
  );

  const renderCourseEditor = (rid) => {
    const c = courses[rid] || { name: "", par: [...DEFAULT_PAR], si: [...DEFAULT_SI] };
    const totalPar = sumArr(c.par);
    const out = sumArr(c.par.slice(0, 9));
    const inn = sumArr(c.par.slice(9));
    const siSet = new Set(c.si);
    const siValid = siSet.size === 18 && [...siSet].every((s) => s >= 1 && s <= 18);

    return (
      <div>
        <button style={{ ...S.btn("ghost"), marginBottom: 14 }} onClick={() => setEditCourse(null)}>← Back to R{rid}</button>
        <div style={S.sh}>Course Setup · R{rid} ({ROUNDS_INFO[rid].name})</div>

        <div style={S.card}>
          <div style={{ fontSize: 11, color: "#4a6a54", marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>Course Name</div>
          <input style={S.inp} placeholder="e.g. Pebble Beach" value={c.name} onChange={(e) => setCourseField(rid, "name", e.target.value)} />
          <button style={{ ...S.btn("ghost"), width: "100%", marginTop: 10 }} onClick={() => applyDefault(rid)}>Reset to Standard Par 72</button>
        </div>

        <div style={{ ...S.card, display: "flex", justifyContent: "space-around", textAlign: "center" }}>
          <div>
            <div style={{ fontSize: 10, color: "#4a6a54", letterSpacing: 1, textTransform: "uppercase" }}>Out</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#c9a84c", fontFamily: "'Playfair Display', serif" }}>{out}</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: "#4a6a54", letterSpacing: 1, textTransform: "uppercase" }}>In</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#c9a84c", fontFamily: "'Playfair Display', serif" }}>{inn}</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: "#4a6a54", letterSpacing: 1, textTransform: "uppercase" }}>Total</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#c9a84c", fontFamily: "'Playfair Display', serif" }}>{totalPar}</div>
          </div>
        </div>

        {!siValid && (<div style={{ ...S.card, borderColor: "#c9a84c40", color: "#c9a84c", fontSize: 11 }}>Stroke Index values must be 1 through 18, each used once.</div>)}

        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr 1fr", gap: 6, alignItems: "center", marginBottom: 4, padding: "0 4px" }}>
          <div style={{ fontSize: 10, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1 }}>Hole</div>
          <div style={{ fontSize: 10, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1, textAlign: "center" }}>Par</div>
          <div style={{ fontSize: 10, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1, textAlign: "center" }}>SI</div>
        </div>
        {[...Array(18)].map((_, h) => (
          <div key={h} style={{ display: "grid", gridTemplateColumns: "auto 1fr 1fr", gap: 6, alignItems: "center", padding: "6px 4px", borderBottom: h === 8 ? "1px dashed rgba(201,168,76,0.2)" : "1px solid rgba(255,255,255,0.04)" }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#9aa490", width: 30 }}>{h + 1}</div>
            <input type="number" min="3" max="6" style={{ ...S.scoreInp, width: "100%" }} value={c.par[h]} onChange={(e) => setCourseHole(rid, "par", h, e.target.value)} />
            <input type="number" min="1" max="18" style={{ ...S.scoreInp, width: "100%" }} value={c.si[h]} onChange={(e) => setCourseHole(rid, "si", h, e.target.value)} />
          </div>
        ))}

        <button style={{ ...S.btn("gold"), width: "100%", marginTop: 16 }} onClick={() => setEditCourse(null)}>Save Course</button>
      </div>
    );
  };

  const renderScoringView = (rid, match) => {
    const format = ROUNDS_INFO[rid].format;
    const course = courses[rid];
    const status = computeMatchStatus(format, course, match, players);
    const allPids = [...match.sideA, ...match.sideB];
    const isScramble = format === "scramble";
    const isVegas = format === "vegas";
    const aTeam = pTeam(match.sideA[0]);
    const bTeam = pTeam(match.sideB[0]);
    const matchIdx = matches[rid].findIndex((m) => m.id === match.id) + 1;
    const teamShort = (n) => { const parts = n.split(" "); return parts[parts.length - 1]; };

    return (
      <div>
        <button style={{ ...S.btn("ghost"), marginBottom: 14 }} onClick={() => setScoring(null)}>← Back to R{rid}</button>

        <div style={{ ...S.card, marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: "#4a6a54", letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 4 }}>Match {matchIdx} · {ROUNDS_INFO[rid].name}</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#c9a84c", marginBottom: 8 }}>{course.name || `Round ${rid} Course`}</div>

          <div style={{ display: "flex", justifyContent: "space-around", padding: "10px 0", borderTop: "1px solid rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: TL[aTeam], fontFamily: "'Playfair Display', serif" }}>{isVegas ? status.vegasA : status.holesA}</div>
              <div style={{ fontSize: 9, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1 }}>{isScramble ? "Side A" : teamNames[aTeam]}</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 11, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1, marginTop: 8 }}>Thru</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: "#9aa490" }}>{status.holesPlayed}</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: TL[bTeam], fontFamily: "'Playfair Display', serif" }}>{isVegas ? status.vegasB : status.holesB}</div>
              <div style={{ fontSize: 9, color: "#4a6a54", textTransform: "uppercase", letterSpacing: 1 }}>{isScramble ? "Side B" : teamNames[bTeam]}</div>
            </div>
          </div>

          <div style={{ marginTop: 12, fontSize: 11 }}>
            {isScramble ? (
              <div>
                <div style={{ color: TL[aTeam] }}>Side A team HCP: <strong>{status.scrambleStrokes?.aHcp ?? 0}</strong>{sumArr(status.scrambleStrokes?.sideA) > 0 && (<span style={{ color: "#9aa490" }}> · gets {sumArr(status.scrambleStrokes?.sideA)} strokes</span>)}</div>
                <div style={{ color: TL[bTeam], marginTop: 4 }}>Side B team HCP: <strong>{status.scrambleStrokes?.bHcp ?? 0}</strong>{sumArr(status.scrambleStrokes?.sideB) > 0 && (<span style={{ color: "#9aa490" }}> · gets {sumArr(status.scrambleStrokes?.sideB)} strokes</span>)}</div>
              </div>
            ) : (
              allPids.map((pid) => {
                const total = sumArr(status.strokesByPid[pid]);
                return (
                  <div key={pid} style={{ marginBottom: 3 }}>
                    <span style={{ color: TL[pTeam(pid)] }}>●</span> <strong>{pName(pid)}</strong> <span style={{ color: "#4a6a54" }}>HCP {pH(pid)}</span><span style={{ color: "#9aa490" }}> · {total === 0 ? "scratch" : `${total} stroke${total !== 1 ? "s" : ""}`}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {[...Array(18)].map((_, h) => {
          const par = course.par[h];
          const si = course.si[h];
          const winner = status.holeWinners?.[h];

          return (
            <div key={h} style={{ ...S.card, marginBottom: 8, padding: "12px", borderColor: winner === "A" ? `${TC[aTeam]}50` : winner === "B" ? `${TC[bTeam]}50` : winner === "H" ? "#c9a84c40" : "rgba(255,255,255,0.06)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: "#c9a84c", fontFamily: "'Playfair Display', serif" }}>Hole {h + 1}</span>
                <span style={{ fontSize: 10, color: "#9aa490" }}>Par {par} · SI {si}</span>
                {winner === "A" && (<span style={{ fontSize: 10, color: TL[aTeam], fontWeight: 700, letterSpacing: 1 }}>{isScramble ? "A" : teamShort(teamNames[aTeam])} +1</span>)}
                {winner === "B" && (<span style={{ fontSize: 10, color: TL[bTeam], fontWeight: 700, letterSpacing: 1 }}>{isScramble ? "B" : teamShort(teamNames[bTeam])} +1</span>)}
                {winner === "H" && (<span style={{ fontSize: 10, color: "#c9a84c", fontWeight: 700, letterSpacing: 1 }}>HALVED</span>)}
              </div>

              {isScramble ? (
                <>
                  <ScoreRow label="Side A" color={TL[aTeam]} strokes={status.scrambleStrokes?.sideA[h] ?? 0} gross={match.scores?.sideA?.[h] ?? ""} par={par} onChange={(v) => setHoleScore(match.id, "sideA", h, v)} S={S} />
                  <ScoreRow label="Side B" color={TL[bTeam]} strokes={status.scrambleStrokes?.sideB[h] ?? 0} gross={match.scores?.sideB?.[h] ?? ""} par={par} onChange={(v) => setHoleScore(match.id, "sideB", h, v)} S={S} />
                </>
              ) : (
                <>
                  {match.sideA.map((pid) => (<ScoreRow key={pid} label={pName(pid)} color={TL[pTeam(pid)]} strokes={status.strokesByPid[pid]?.[h] ?? 0} gross={match.scores?.[pid]?.[h] ?? ""} par={par} onChange={(v) => setHoleScore(match.id, pid, h, v)} S={S} />))}
                  <div style={{ height: 6 }} />
                  {match.sideB.map((pid) => (<ScoreRow key={pid} label={pName(pid)} color={TL[pTeam(pid)]} strokes={status.strokesByPid[pid]?.[h] ?? 0} gross={match.scores?.[pid]?.[h] ?? ""} par={par} onChange={(v) => setHoleScore(match.id, pid, h, v)} S={S} />))}
                </>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const renderRound = (rid) => {
    if (scoring && scoring.rid === rid) {
      const m = (matches[rid] || []).find((x) => x.id === scoring.mid);
      if (m) return renderScoringView(rid, m);
    }
    if (editCourse === rid) return renderCourseEditor(rid);

    const info = ROUNDS_INFO[rid];
    const format = info.format;
    const course = courses[rid];
    const rMatches = matches[rid] || [];
    const pts = getRoundPts(rid);

    return (
      <div>
        <div style={{ ...S.card, marginBottom: 14, borderColor: "rgba(201,168,76,0.15)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#c9a84c", marginBottom: 4 }}>{info.name}</div>
          <div style={{ fontSize: 11, color: "#4a6a54", marginBottom: 12 }}>{info.desc}</div>
          <div style={{ display: "flex", gap: 16 }}>
            {[0, 1].map((i) => (<span key={i} style={{ fontSize: 12, color: TL[i] }}>{teamNames[i]}: <strong style={{ fontFamily: "'Playfair Display', serif", fontSize: 18 }}>{pts[i]}</strong></span>))}
          </div>
        </div>

        {course ? (
          <div style={{ ...S.card, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }} onClick={() => setEditCourse(rid)}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#c9a84c" }}>{course.name || `Round ${rid} Course`}</div>
              <div style={{ fontSize: 11, color: "#4a6a54", marginTop: 2 }}>Par {sumArr(course.par)} · 18 holes</div>
            </div>
            <div style={{ fontSize: 11, color: "#4a6a54" }}>Edit ▶</div>
          </div>
        ) : (
          <button style={{ ...S.btn("ghost"), width: "100%", marginBottom: 14, padding: "14px" }} onClick={() => initCourse(rid)}>Set up course for {info.name}</button>
        )}

        {rMatches.map((m, idx) => {
          const status = course ? computeMatchStatus(format, course, m, players) : null;
          const sideResult = getMatchSideResult(rid, m);
          const aTeam = pTeam(m.sideA[0]);
          const bTeam = pTeam(m.sideB[0]);
          const hasScores = matchHasScores(m);

          return (
            <div key={m.id} style={S.card}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <span style={{ fontSize: 10, color: "#4a6a54", fontWeight: 600, letterSpacing: 1.5, textTransform: "uppercase" }}>Match {idx + 1}</span>
                <button onClick={() => removeMatch(m.id)} style={{ background: "none", border: "none", color: "#3a4a3a", cursor: "pointer", fontSize: 18, padding: 0 }}>×</button>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: 8, alignItems: "center", marginBottom: 12 }}>
                <div>
                  {m.sideA.map((pid) => (<div key={pid} style={{ fontSize: 12, marginBottom: 2 }}><span style={{ color: TL[pTeam(pid)] }}>●</span> {pName(pid)} <span style={{ color: "#4a6a54" }}>({pH(pid)})</span></div>))}
                  {m.sideA.length === 0 && <div style={{ fontSize: 11, color: "#3a4a3a" }}>Side A</div>}
                </div>
                <div style={{ fontSize: 11, color: "#3a4a3a", textAlign: "center" }}>vs</div>
                <div style={{ textAlign: "right" }}>
                  {m.sideB.map((pid) => (<div key={pid} style={{ fontSize: 12, marginBottom: 2 }}>{pName(pid)} <span style={{ color: "#4a6a54" }}>({pH(pid)})</span> <span style={{ color: TL[pTeam(pid)] }}>●</span></div>))}
                  {m.sideB.length === 0 && <div style={{ fontSize: 11, color: "#3a4a3a" }}>Side B</div>}
                </div>
              </div>

              {status && status.holesPlayed > 0 && (
                <div style={{ padding: "8px 10px", background: "rgba(0,0,0,0.2)", borderRadius: 6, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: "#9aa490" }}>{format === "vegas" ? `Vegas: ${status.vegasA} - ${status.vegasB}` : `Holes: ${status.holesA} - ${status.holesB}`}</span>
                  <span style={{ fontSize: 10, color: "#4a6a54" }}>Thru {status.holesPlayed}</span>
                </div>
              )}

              {hasScores ? (
                sideResult && (
                  <div style={{ padding: "8px 10px", background: sideResult === "tie" ? "rgba(201,168,76,0.1)" : sideResult === "sideA" ? `${TC[aTeam]}25` : `${TC[bTeam]}25`, border: `1px solid ${sideResult === "tie" ? "#c9a84c50" : sideResult === "sideA" ? `${TC[aTeam]}60` : `${TC[bTeam]}60`}`, borderRadius: 6, fontSize: 11, fontWeight: 600, textAlign: "center", color: sideResult === "tie" ? "#c9a84c" : sideResult === "sideA" ? TL[aTeam] : TL[bTeam] }}>
                    {sideResult === "tie" ? "HALVED" : sideResult === "sideA" ? `${teamNames[aTeam]} ${status.holesPlayed === 18 ? "win" : "leading"}` : `${teamNames[bTeam]} ${status.holesPlayed === 18 ? "win" : "leading"}`}
                  </div>
                )
              ) : course ? (
                <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                  <button style={S.rBtn(m.manualResult === "t1", TL[0])} onClick={() => setManualResult(m.id, "t1")}>{teamNames[0].split(" ")[0]} Win</button>
                  <button style={S.rBtn(m.manualResult === "tie", "#c9a84c")} onClick={() => setManualResult(m.id, "tie")}>Tie</button>
                  <button style={S.rBtn(m.manualResult === "t2", TL[1])} onClick={() => setManualResult(m.id, "t2")}>{teamNames[1].split(" ")[0]} Win</button>
                </div>
              ) : (
                <div style={{ fontSize: 10, color: "#4a6a54", textAlign: "center", padding: "8px 0", fontStyle: "italic" }}>Set up the course to enter scores</div>
              )}

              {course && (<button style={{ ...S.btn("ghost"), width: "100%", marginTop: 8 }} onClick={() => setScoring({ rid, mid: m.id })}>{hasScores ? "Edit Scores" : "Enter Scores"}</button>)}
            </div>
          );
        })}

        <button style={{ ...S.btn("ghost"), width: "100%", marginTop: 6 }} onClick={() => setModal({ rid, sideA: [], sideB: [] })}>+ Add Match</button>
      </div>
    );
  };

  const renderModal = () => {
    if (!modal) return null;
    const usedIds = new Set((matches[modal.rid] || []).flatMap((m) => [...m.sideA, ...m.sideB]));
    const avail = players.filter((p) => p.team !== null && !usedIds.has(p.id));

    return (
      <div style={S.overlay} onClick={(e) => e.target === e.currentTarget && setModal(null)}>
        <div style={S.modalBox}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, fontWeight: 700, color: "#c9a84c", marginBottom: 16 }}>Configure Match</div>
          {avail.length === 0 && (<div style={{ fontSize: 12, color: "#4a6a54", marginBottom: 16 }}>All drafted players are already in matches this round.</div>)}
          {["sideA", "sideB"].map((sk, si) => {
            const other = sk === "sideA" ? "sideB" : "sideA";
            const availForSide = avail.filter((p) => !modal[other].includes(p.id));
            return (
              <div key={sk} style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 10, fontWeight: 600, color: "#6a8a74", textTransform: "uppercase", letterSpacing: 2, marginBottom: 8 }}>Side {si === 0 ? "A" : "B"} {modal[sk].length > 0 ? `(${modal[sk].length} selected)` : ""}</div>
                <div style={{ display: "flex", flexWrap: "wrap" }}>
                  {availForSide.map((p) => {
                    const sel = modal[sk].includes(p.id);
                    return (
                      <div key={p.id} style={S.chip(p.team, sel)} onClick={() => toggleSide(sk, p.id)}>
                        <div style={{ width: 6, height: 6, borderRadius: "50%", background: sel ? "#fff" : TC[p.team] }} />
                        {p.name} ({p.handicap})
                      </div>
                    );
                  })}
                  {availForSide.length === 0 && !avail.length && (<div style={{ fontSize: 11, color: "#3a4a3a" }}>No players available</div>)}
                </div>
              </div>
            );
          })}
          <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
            <button style={{ ...S.btn(), flex: 1 }} onClick={() => setModal(null)}>Cancel</button>
            <button style={{ ...S.btn("gold"), flex: 2, opacity: modal.sideA.length === 0 && modal.sideB.length === 0 ? 0.4 : 1 }} onClick={handleAddMatch}>Add Match</button>
          </div>
        </div>
      </div>
    );
  };

  const TABS = [
    { id: "roster", label: "Roster" },
    { id: "draft", label: "Draft" },
    { id: "board", label: "Board" },
    { id: "r1", label: "R1" },
    { id: "r2", label: "R2" },
    { id: "r3", label: "R3" },
    { id: "r4", label: "R4" },
  ];

  return (
    <div style={S.app}>
      <div style={S.hdr}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div style={S.title}>Golf Trip 2026</div>
          <div style={{ fontSize: 10, color: "#4a6a54", letterSpacing: 2, textTransform: "uppercase" }}>{tripCode}</div>
        </div>
        <div style={S.sub}>72 Holes · 4 Formats · 2 Teams</div>
        <div style={S.scoreRow}>
          {[0, 1].map((i) => (
            <div key={i} style={S.sBox(i, totalPts[i] > totalPts[1 - i])}>
              {totalPts[i] > totalPts[1 - i] && (<div style={{ position: "absolute", top: 5, right: 8, fontSize: 9, color: TL[i], fontWeight: 700, letterSpacing: 1 }}>LEADING</div>)}
              <div style={S.sNum(i)}>{totalPts[i]}</div>
              <div style={S.sLbl}>{teamNames[i]}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={S.tabBar}>
        {TABS.map((t) => (<button key={t.id} style={S.tab(view === t.id)} onClick={() => { setView(t.id); setScoring(null); setEditCourse(null); }}>{t.label}</button>))}
      </div>

      <div style={S.content}>
        {view === "roster" && renderRoster()}
        {view === "draft" && renderDraft()}
        {view === "board" && renderBoard()}
        {view === "r1" && renderRound(1)}
        {view === "r2" && renderRound(2)}
        {view === "r3" && renderRound(3)}
        {view === "r4" && renderRound(4)}
      </div>

      {renderModal()}
    </div>
  );
}

// =====================================================
// SCORE ROW with optimistic state + debounced writes
// =====================================================
function ScoreRow({ label, color, strokes, gross, par, onChange, S }) {
  const [local, setLocal] = useState(gross ?? "");
  const focusedRef = useRef(false);
  const debounceRef = useRef(null);
  const pendingRemoteRef = useRef(null);

  // Sync from remote when not actively editing
  useEffect(() => {
    if (!focusedRef.current) {
      setLocal(gross ?? "");
      pendingRemoteRef.current = null;
    } else {
      pendingRemoteRef.current = gross ?? "";
    }
  }, [gross]);

  // Cleanup pending debounce on unmount
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const handleChange = (e) => {
    const v = e.target.value;
    setLocal(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      onChange(v);
    }, 300);
  };

  const handleFocus = () => {
    focusedRef.current = true;
  };

  const handleBlur = () => {
    focusedRef.current = false;
    // Flush any pending debounced write immediately on blur
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
      debounceRef.current = null;
      onChange(local);
    }
    // Apply any remote update that arrived while focused
    if (pendingRemoteRef.current !== null && pendingRemoteRef.current !== local) {
      setLocal(pendingRemoteRef.current);
    }
    pendingRemoteRef.current = null;
  };

  const grossNum = parseFloat(local);
  const filled = local !== "" && !isNaN(grossNum);
  const net = filled ? grossNum - strokes : null;
  const netVsPar = net != null ? net - par : null;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0" }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: color, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {label}
          {strokes > 0 && (<span style={{ marginLeft: 4, color: "#c9a84c", fontSize: 10 }}>{Array(strokes).fill("•").join("")}</span>)}
        </div>
      </div>
      <input
        type="number"
        min="1"
        max="20"
        placeholder="–"
        style={S.scoreInp}
        value={local}
        onChange={handleChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        inputMode="numeric"
      />
      <div style={{ width: 50, textAlign: "right", fontSize: 11, color: "#9aa490" }}>
        {net != null ? (<><span style={{ color: "#9aa490" }}>net</span> <strong style={{ color: netVsPar < 0 ? "#5ecea0" : netVsPar > 0 ? "#9aa490" : "#c9a84c" }}>{net}</strong></>) : (<span style={{ color: "#3a4a3a" }}>—</span>)}
      </div>
    </div>
  );
}
